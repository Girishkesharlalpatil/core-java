package Day16;
public class Overriding {
	public static void main(String[] args) {
		 Overriding o = new  Overriding();
		 Two t = new Two();
		 Three th = new Three();
		 o.one(10);
		 th.one(60);
		 t.one(0);
	}
	void one (int a) {
		  System.out.println("Class One");
	}
}
class Two{
	 void one (int a) {
		  System.out.println("Class Two");
		}
}
class Three{
	 void one (int a) {
			  System.out.println("Class Three");
		}
}