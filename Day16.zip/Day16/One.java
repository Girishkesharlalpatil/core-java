package Day16;

//OverLoading Method
public class One {
     
	public void one(int a , String b){
		System.out.println("one");
	}
	public void one(){
		System.out.println("one1");
	}
	public void one( int...a){
		System.out.println("one3");
	}
	public static void main(String[] args) {
		One o = new One();
		o.one( 20, 40,50,20,50,30,230,023,230,239 );
//		o.one( 10,"Chetan"  );
	}
}


