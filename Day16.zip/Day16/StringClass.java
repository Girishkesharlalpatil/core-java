package Day16;

public class StringClass {
      public static void main(String[] args) {
    	  
//    	  String Classes 
		      String str ="Hello";
		      String str2 = "World";
		      
		      String Result = str +" "+str2;
		      
		      System.out.println(Result);
		      System.out.println(Result.length());
		      System.out.println(Result.charAt(6));
		      
		      
	  }
}
