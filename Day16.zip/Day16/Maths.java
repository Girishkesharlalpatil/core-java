package Day16;

public class Maths {
  public static void main(String[] args) {
	 int result =Math.max(40, 60);
	 double one =Math.sqrt(4);
	 double one1 =Math.pow( 2 , 3);
	 
	 System.out.println(result);
	 System.out.println(one);
	 System.out.println(one1);
}
}

