package com.org;

public class Grand {
		
		public void grandParentProperty() {
	        System.out.println("Grandparent has a house.");
	    }
	}


	class Parent extends  Grand{
	    public void parentSkill() {
	        System.out.println("Parent is a good cook.S");
	    }
	}


	class Child extends Parent {
	    public void childHobby() {
	        System.out.println("Child likes to play video games.");
	    }


	public static void main(String[] args) {
	    Child myChild = new Child();

	    myChild.grandParentProperty(); 
	    myChild.parentSkill();      
	    myChild.childHobby();   
	    
	    
	    
	}
	}


