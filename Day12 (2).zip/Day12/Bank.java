package com.org;

public class Bank {

	 public void credit(double amount) {
	        System.out.println("Crediting amount: " + amount);
	    }

	    public void debit(double amount) {
	        System.out.println("Debiting amount: " + amount);
	    }

	    public static void main(String[] args) {
	        Bank bank = new Bank();
	        Credit creditOperation = new Credit();
	        Debit debitOperation = new Debit();

	        bank.credit(1000.0);
	        bank.debit(500.0);  

	        creditOperation.doCredit(500.0); 
	        debitOperation.doDebit(200.0);   

	    }
	}

	
	class Credit extends Bank {
	    public void doCredit(double amount) {
	        System.out.println("Performing Credit Operation:");
	        credit(amount); 
	        System.out.println("Credit Operation Completed.");
	    }
	}

	class Debit extends Bank {
	    public void doDebit(double amount) {
	        System.out.println("Performing Debit Operation:");
	        debit(amount);
	        System.out.println("Debit Operation Completed.");
	    }
	}
