package com.org;



class A{
		
    void methodA() {
    	System.out.println("method of A class ");
    }
	
	}
class B extends A{
	 void methodB() {
	    	System.out.println("method of b class ");
	    }
		
	}
class C extends B{
	 void methodc() {
	    	System.out.println("method of c class ");
	    }		
}
       public class Practice{
    	   
      public static void main (String args[]) {
    	  
    	C obj = new C();
    	obj.methodA();
    	obj.methodB();
    	obj.methodc();
      }
      }