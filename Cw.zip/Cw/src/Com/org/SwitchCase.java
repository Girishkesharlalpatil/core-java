package Com.org;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println("enter a number");
		int number1 = sc.nextInt();
		
		
		System.out.println("enter a number");
		int number2 = sc.nextInt();
		
		
		
		System.out.println(" no 0 choose an operator");
		System.out.println(" no 1 Addition (+)");
		System.out.println("no 2 substraction (-)");
		System.out.println("no 3 multipilcation(*)");
		System.out.println("no 4 Division (-)");
		
		
		
		
		
	int choise = sc.nextInt();
	int result;
	
	
	switch (choise) {
	case 1:
		
		 result = number1 + number2;
		System.out.println("addition of numbers "+ result);
		
		break;
		
	case 2:
		result = number1 - number2;
		System.out.println("substraction of numbers "+ result);
		
		break;
		
	case 3:
		
		result = number1 * number2;
		System.out.println("multiplication of numbers "+ result);
		
		break;
		
	case 4:
		
		result = number1 / number2;
		System.out.println("Division  of numbers "+ result);
		
		break;
	
		
		

	}
	
	
	System.out.println("enter a number");
	int number3 = sc.nextInt();
	
	System.out.println("enter a number");
	int number4 = sc.nextInt();
	
	
	System.out.println(" no 0 choose an operator");
	System.out.println(" no 1 Addition (+)");
	System.out.println("no 2 substraction (-)");
	System.out.println("no 3 multipilcation(*)");
	System.out.println("no 4 Division (-)");
	
	
	int Main = sc.nextInt();
	int sam;
	
	switch (Main) {
	case 1:
		
		 sam = number3 + number4;
		System.out.println("addition of numbers "+ sam);
		
		break;
		
	case 2:
		
		 sam = number1 + number2;
		System.out.println("addition of numbers "+ sam);
		
		break;
	
	
	
	

	}
	}
}
	
