package Com.org;

import java.util.Scanner;

public class FindGrade {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a marks");
		int Marks =  sc.nextInt();
		
		if(Marks>90) {
			System.out.println("Grade A");
			
		}else if (Marks>70) {
			System.out.println("Grade B");
				
		}else if (Marks>50) {
			System.out.println("Grade c");
			
		}else if (Marks>35) {
			System.out.println("Grade D");
			
		}else {
			System.out.println("Fail");
			
		}
	}

}
