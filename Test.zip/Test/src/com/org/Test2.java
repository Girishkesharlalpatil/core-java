//
//
//	1) Vector
//
//	Basic Definition: A vector is like a container that holds a sequence of elements, similar to an array. However, vectors can dynamically resize themselves, meaning they can grow or shrink as needed.
//	Key Features:
//	Dynamic Sizing: Unlike fixed-size arrays, vectors can efficiently add or remove elements without you having to manage memory allocation manually.
//	Contiguous Storage: Elements in a vector are stored next to each other in memory, allowing for fast access to individual elements using their index (position).
//	Use Cases: Vectors are widely used when you need a collection of elements that might change in size during the program's execution.

//	2) ArrayList
//
//	Basic Definition: An ArrayList is a specific implementation of a dynamic array (similar to a vector) found in many programming languages like Java.
//	Key Features:
//	Dynamic Array: It automatically increases its capacity when you add more elements than it can currently hold.
//	Ordered Collection: Elements are stored in the order they were added, and you can access them using their index.
//	Not Synchronized: In a multi-threaded environment, you might need to add explicit synchronization mechanisms to avoid issues when multiple threads access the ArrayList concurrently.
//	Use Cases: ArrayLists are a go-to choice when you need a resizable array and don't require thread safety or very high performance for specific operations.

//	3) LinkedList
//
//	Basic Definition: A LinkedList is a linear collection of elements where each element (node) stores its data and a reference (link) to the next element in the sequence.
//	Key Features:
//	Non-Contiguous Storage: Elements are not stored in adjacent memory locations. Instead, they are scattered in memory, and the links between them maintain the order.
//	Efficient Insertion/Deletion: Adding or removing elements in the middle of a LinkedList is generally faster than in an ArrayList because you only need to update the links.
//	Slower Random Access: Accessing an element at a specific index in a LinkedList requires traversing the list from the beginning, making it slower than ArrayList for random access.
//	Use Cases: LinkedLists are suitable when you frequently need to insert or delete elements at arbitrary positions within the collection.

//	4) Queue
//
//	Basic Definition: A queue is a collection that follows the "First-In, First-Out" (FIFO) principle. Think of it like a real-life queue (or line) where the first person who joins is the first one to be served.
//	Key Features:
//	FIFO Order: Elements are removed from the queue in the same order they were added.
//	Enqueue/Dequeue: Adding an element to the rear of the queue is called "enqueue," and removing an element from the front is called "dequeue."
//	Use Cases: Queues are used in various scenarios, such as:
//	Task scheduling: Processing tasks in the order they were submitted.
//	Breadth-first search: Exploring a graph level by level.
//	Handling requests: Managing incoming requests in a server.

