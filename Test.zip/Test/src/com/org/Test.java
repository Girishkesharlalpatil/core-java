package com.org;

import java.util.Vector;

public class Test {

	public static void main(String[] args) {
		Vector<String> vector = new Vector<>();

       
        vector.add("Red");
        vector.add("Green");
        vector.add("Blue");
        System.out.println("Vector after adding elements: " + vector);

     
        vector.add(1, "Yellow");
        System.out.println("Vector after inserting Yellow at index 1: " + vector);

        System.out.println("Element at index 2: " + vector.get(2));

       
        vector.remove("Green");
        System.out.println("Vector after removing Green: " + vector);

      
        boolean containsBlue = vector.contains("Blue");
        System.out.println("Does the vector contain Blue? " + containsBlue);

        
        System.out.println("Size of the Vector: " + vector.size());

      
        vector.clear();
        System.out.println("Vector after clearing: " + vector);
    }

	}


