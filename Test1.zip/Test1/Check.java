package Test1;

public class Check {
	public static void main(String args[]) {
		int a = 55;
		int b = 70;
		
		if(a>50 && a<b) {
			System.out.print(true);
		}
	}
}
