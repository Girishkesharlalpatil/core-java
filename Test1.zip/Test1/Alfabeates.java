package Test1;

public class Alfabeates {
	public static void main(String args[]) {
		for (char i = 'A'; i <= 'Z'; i++) {
			System.out.print(i + " ");
		}
	}
}
