package com.org;

import java.util.Scanner;

public class Experiance {



		
		   public static void main(String[] args) {
		      
			
		        Scanner sc = new Scanner(System.in);
		        
		        System.out.print("Enter a experiance ");
		        int experiance = sc.nextInt();	 
		        
		        try {
		        	
		        
		       	 if (experiance < 2	) {
				     
				     System.out.println("Experience less than one year. You cannot apply for the job.");
				 }else {
					 System.out.println("you apply for the job");
				 }
		        	
		        }catch(Exception e) {
		        	
		        	System.out.println("You are eligible to apply for the job");
		        }
		
		
		   }
}
