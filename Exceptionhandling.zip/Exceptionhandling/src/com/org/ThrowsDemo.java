package com.org;

public class ThrowsDemo {


	  
	    public static void readFile(String filename) throws FileNotFoundException {
	       
	        File file = new File(filename);
	        Scanner scanner = new Scanner(file); 

	        while (scanner.hasNextLine()) {
	            System.out.println(scanner.nextLine());
	        }
	        scanner.close(); 
	        System.out.println("File read successfully.");
	    }

	    public static void main(String[] args) {
	        String existingFile = "existing_file.txt"; 
	        String nonExistentFile = "non_existent_file.txt";

	        try {
	            System.out.println("Trying to read an existing file:");
	            readFile(existingFile);
	        } catch (FileNotFoundException e) {
	            System.err.println("Error: File not found: " + e.getMessage());
	        }

	        System.out.println("\n--------------------\n");

	      
	        try {
	            System.out.println("Trying to read a non-existent file:");
	            readFile(nonExistentFile);
	        } catch (FileNotFoundException e) {
	            System.err.println("Error: File not found: " + e.getMessage());
	        }
	        System.out.println("\n--------------------\n");

	  

	        System.out.println("Program finished.");
	    }
	}

