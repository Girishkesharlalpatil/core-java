package com.org;

import java.util.Scanner;

public class EasyDivideByZero{
	
	try {
   Scanner sc = new Scanner(System.in);
    int no = sc.nextInt();
   
	int number = 10;
	int number2 = 0;
	
	int result = number/number2;
	
	}catch(Exception e) {
		System.out.println("does not divided by zero");
		
	}
	
	

}
}