package com.org;

import java.util.Scanner;

public class StudentAdmission {
    
	
	   public static void main(String[] args) {
	      
	        Scanner sc = new Scanner(System.in);


	        System.out.print("Enter a name ");
	        String name = sc.nextLine();

	        System.out.print("Enter a age ");
	        String age = sc.nextLine();
	        
	        try {
	        	   if(age<3) {
	        		System.out.println("he is able to take a admision ");
	        	   }
	        	
	        }catch(Exception e) {
	        	System.out.println("not able to admission");
	        }
	
	
	
	
	
	
	   }
	
}