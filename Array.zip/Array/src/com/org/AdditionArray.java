package com.org;

import java.util.Arrays;

public class AdditionArray {

	public static void main(String[] args) {
		
		
		int[] num1 = {1,2,3,4,5};
		int[] num2 = {1,2,3,4,5};
		
		int[] result = new int [num1.length];
		
		for(int i=0; i<num1.length; i++) {
			result[i] = num1[i] + num2[i];	
		}
		
		System.out.println("result in array: "+ result);
		
		}
		
		
	
		
		
		}
	}


