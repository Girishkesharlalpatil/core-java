package com.org;

public class languageName {
  
	private String programinglangavge;
	
	public languageName(String name) {
		programinglangavge = name;
	}
	public void displayLanguageName() {
		System.out.println("programing languages " +programinglangavge);
	}
	
	public static void main(String[] args) {
		
		languageName lang1 = new languageName("java");
		languageName lang2 = new languageName("python");
		languageName lang3 = new languageName("c++");
		languageName lang4 = new languageName("javascript");
		
		lang1.displayLanguageName();
		lang2.displayLanguageName();
		lang3.displayLanguageName();
		lang4.displayLanguageName();
	}
}
