package com.org;

public class Student {

      String name;
      int marks1;
      int marks2;
      
  public Student (String Studentname, int subject1mark, int subeject2marks) {
	  
	   name =  Studentname;
	   marks1 = subject1mark;
	   marks2 = subeject2marks;
  }
        public void CalculateDisplay() {
        	double average = (marks1 + marks2) /2.0;
        	System.out.println("average marks " +name+ "average " + average);
        }
        public static void main(String[] args) {
               
        	Student Student1 = new Student("chetan " ,80,90);
        	Student Student2 = new Student("Ram ", 50,65);
        	
        	
        	Student1.CalculateDisplay();
        	Student2.CalculateDisplay();
		}
    
    
      

}
