package com.org;

public class PrintNmeusingConstructor {

      	private String MyName;
		
         public PrintNmeusingConstructor() {
        	   MyName = "Girish";
        	   
         }
         public void DisplayMyName() {
        	 System.out.println("my name is "+MyName);
         }
         public static void main(String[] args) {
        	 PrintNmeusingConstructor obj = new  PrintNmeusingConstructor();
        	 obj.DisplayMyName();
		}
	}


