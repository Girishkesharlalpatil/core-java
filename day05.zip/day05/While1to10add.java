package day05;

public class While1to10add {

	public static void main(String[] args) {
		
		        int number = 1, sum = 0;

		        while (number <= 10) {
		            sum += number;
		            number++;
		        }

		        System.out.println("Sum of numbers from 1 to 10 is: " + sum);
		    }
		

	}


