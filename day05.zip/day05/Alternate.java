package day05;

public class Alternate {

	public static void main(String[] args) {
		
		   
		        int number = 1;

		        while (number <= 50) {
		            System.out.println(number);
		            number += 2; // Increment by 2 to get alternate numbers
		        }
		    }
		}
	


