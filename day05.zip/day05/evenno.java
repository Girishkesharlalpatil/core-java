package day05;

public class evenno {

	public static void main(String[] args) {
		int number = 0;
		while(number<=50) {
			System.out.println(number);
			number+=2;
		}

	}

}
