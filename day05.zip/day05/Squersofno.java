package day05;

public class Squersofno {

	public static void main(String[] args) {
		
		   
		        for (int i = 1; i <= 20; i++) {
		            int square = i * i;
		            System.out.println("Square of " + i + " is: " + square);
		        }
		    }
		

	}


