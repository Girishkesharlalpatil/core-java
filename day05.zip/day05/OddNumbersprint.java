package day05;

public class OddNumbersprint {

	public class OddNumbers {
	    public static void main(String[] args) {
	        for (int i = 101; i <= 110; i++) {
	            if (i % 2 != 0) {
	                System.out.println(i);
	            }
	        }
	    }
	}

	}


