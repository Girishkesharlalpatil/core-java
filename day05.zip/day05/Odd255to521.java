package day05;

public class Odd255to521 {

	public static void main(String[] args) {
		
		    
		        int number = 521;

		        do {
		            if (number % 2 != 0) {
		                System.out.println(number);
		            }
		            number--;
		        } while (number >= 229);
		    }
		

	}


