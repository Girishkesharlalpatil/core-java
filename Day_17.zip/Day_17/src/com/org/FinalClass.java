package com.org;

public class FinalClass {

	

	final class Animal {
	    public void display() {
	        System.out.println("This is a final class.");
	    }
	}



	public class FinalClassExample {
	    public static void main(String[] args) {
	     
	    	FinalClass animal = new FinalClass();
	    	 animal.display();
	    }
	}

}
