package com.org;

public class FinalMethod {

  
     final public  void displayMessage() {
        System.out.println("This is a final method.");
    }

    public void regularMethod() {
        System.out.println("This is a regular (non-final) method.");
    }

    public static void main(String[] args) {
    	FinalMethod parent = new FinalMethod();
        parent.displayMessage(); 
        parent.regularMethod(); 

        ChildClass child = new ChildClass();
        child.displayMessage(); 
        child.regularMethod();
    }
}

class ChildClass extends FinalMethod{

	
	public void regularMethod() {
        System.out.println("This is the child's regular method");
        
	}
	
	
}

 