package com.org;

public class FinalKeyword {

    public static void main(String[] args) {
        
        final int AGE = 18;

    
        System.out.println("The legal age is: " + AGE);

       
    }
}
