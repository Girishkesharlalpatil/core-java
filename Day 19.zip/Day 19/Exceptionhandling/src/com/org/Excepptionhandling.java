//package com.org;
//
//public class Excepptionhandling {
//
//	
//	
//	
//        1)	What is an Exception? 
//			
//			An exception is an event or condition that occurs during the execution of a
//			program and disrupts its normal flow. Exceptions typically arise due to errors
//			such as invalid user input, attempting to divide by zero, accessing a file that 
//			doesn't exist, or running out of memory.
//			
//			
//		2)	what are types of excepption?
//
//         1). Checked Exceptions
//           Checked exceptions are exceptions that are checked at compile time. If a 
//        method can throw a checked exception, it must either handle it using
//         a try-catch block or declare it in the method signature using the throws keyword.
//         
//         
//         
//         2. Unchecked Exceptions
//         Unchecked exceptions are exceptions that are not checked at compile time.
//         They occur during runtime and are often caused by programming errors such as 
//         logical mistakes or improper 
//         use of APIs. These exceptions extend the RuntimeException class.
//         
//         
//         3. Errors
//         Errors represent serious problems that a program typically cannot handle. They usually
//         indicate issues in the runtime environment, such as hardware or system-level problems. Errors extend the
//         Error class and are not exceptions in the traditional sense.
//         
//         
//        3) Deffernece between checked and unchecked exception?
//
//          1. Checked Exceptions:
//          Definition: Checked exceptions are exceptions that are checked at compile-time.
//          The compiler ensures that you handle or declare these exceptions in your code.
//          Handling: You must either
//          
//         2. Unchecked Exceptions:
//         Definition: Unchecked exceptions are exceptions that are not checked at compile-time. 
//         They occur during runtime, typically due to programming errors
//         (like logical mistakes or incorrect use of APIs).
//         Handling: You are not required to handle or declare unchecked exceptions, 
//         although it's still good practice to do so if they can occur in your code.
//         
//         
//         
//        4)  what is defference between throw and throw keywords?
//
//         1. throw Statement:
//        	 Purpose: The throw statement is used to explicitly throw an exception from within a method or block of code.
//        	 Usage: It is used when you want to manually trigger an exception based on some condition in the code.
//                
//         2. throws Statement:
//        	Purpose: The throws statement is used in a method signature to declare that a
//        	method may throw one or more exceptions.
//        	Usage: It is used to indicate that a method is capable of throwing certain exceptions, 
//        	and the caller of the method must handle these exceptions.
//}
